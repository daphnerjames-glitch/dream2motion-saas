import sys
import subprocess

# Install required packages if not available
try:
    import functions_framework
except ImportError:
    subprocess.check_call([sys.executable, "-m", "pip", "install", "functions-framework==3.5.0", "requests==2.31.0"])
    import functions_framework

import json
import logging
import requests
from datetime import datetime
import os

logging.basicConfig(level=logging.INFO)

# API Keys
GRANNY_VIDU_KEY = "vda_952254575019040768_zJiqalVnTrmhUuDZQPv3KCK3WcA3RGMV"
REBEL_VIDU_KEY = "vda_952306322504687616_1rkmxncjGMeBnYXLLKYdc8d5eS9yy2tk"
ETSY_API_KEY = "prmwtrvb9gdxyu7cl90syii7"
ETSY_SHARED_SECRET = "0e7p6mx7zf"

@functions_framework.http
def process_income_engine_pipeline(request):
    """
    Receives orchestrated payloads from Google Apps Script.
    Routes to appropriate processing pipeline based on channel.
    """

    # Handle CORS
    if request.method == 'OPTIONS':
        headers = {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'POST',
            'Access-Control-Allow-Headers': 'Content-Type',
            'Access-Control-Max-Age': '3600'
        }
        return ('', 204, headers)

    cors_headers = {'Access-Control-Allow-Origin': '*'}

    try:
        payload = request.get_json(silent=True)

        # Validate payload
        if not payload or 'token' not in payload or 'channel' not in payload:
            return (json.dumps({
                'status': 'rejected',
                'reason': 'Invalid payload structure'
            }), 400, cors_headers)

        # Security check
        if payload['token'] != 'closetrebel2026':
            return (json.dumps({
                'status': 'unauthorized',
                'reason': 'Invalid security token'
            }), 403, cors_headers)

        channel = payload.get('channel')
        row_data = payload.get('data', {})
        row_number = payload.get('rowNumber')

        logging.info(f"Processing channel: {channel}, row: {row_number}")
        logging.info(f"Title: {row_data.get('title')}")

        # Route to channel handler
        if channel == 'granny':
            result = handle_granny_youtube(row_data, payload)
        elif channel == 'rebel':
            result = handle_rebel_youtube(row_data, payload)
        elif channel == 'etsy':
            result = handle_etsy(row_data, payload)
        else:
            return (json.dumps({
                'status': 'error',
                'reason': f'Unknown channel: {channel}'
            }), 400, cors_headers)

        return (json.dumps({
            'status': 'success',
            'channel': channel,
            'result': result,
            'timestamp': datetime.now().isoformat()
        }), 200, cors_headers)

    except Exception as e:
        logging.error(f"Engine error: {str(e)}")
        return (json.dumps({
            'status': 'error',
            'error_details': str(e)
        }), 500, cors_headers)


def call_vidu_api(title, description, vidu_key, aspect_ratio="16:9"):
    """
    Call Vidu API to generate video
    aspect_ratio: "16:9" for YouTube, "9:16" for Shorts
    """
    try:
        url = "https://api.vidu.ai/v1/generate"
        headers = {
            "Authorization": f"Bearer {vidu_key}",
            "Content-Type": "application/json"
        }

        prompt = f"{title}. {description}"

        payload = {
            "model": "vidu-1.0",
            "prompt": prompt,
            "aspect_ratio": aspect_ratio,
            "duration": 60
        }

        response = requests.post(url, json=payload, headers=headers, timeout=30)

        if response.status_code == 200:
            result = response.json()
            video_id = result.get('id')
            logging.info(f"Vidu video generation started: {video_id}")
            return {
                'status': 'generating',
                'video_id': video_id,
                'message': 'Video generation in progress'
            }
        else:
            logging.error(f"Vidu API error: {response.text}")
            return {
                'status': 'error',
                'message': f'Vidu API error: {response.status_code}'
            }
    except Exception as e:
        logging.error(f"Vidu API call failed: {str(e)}")
        return {
            'status': 'error',
            'message': str(e)
        }


def handle_granny_youtube(data, payload):
    """
    Process Granny YouTube content:
    1. Call Vidu API to generate video
    2. Upload to YouTube (assumes auth is in Cloud environment)
    3. Extract audio and post to Buzzsprout
    4. Update sheet with status
    """
    title = data.get('title', 'Untitled')
    description = data.get('description', '')

    logging.info(f"Handling Granny YouTube: {title}")

    # Call Vidu API
    vidu_result = call_vidu_api(title, description, GRANNY_VIDU_KEY, aspect_ratio="16:9")

    return {
        'title': title,
        'channel': 'granny',
        'vidu_status': vidu_result.get('status'),
        'vidu_video_id': vidu_result.get('video_id'),
        'message': 'Granny video generation initiated'
    }


def handle_rebel_youtube(data, payload):
    """
    Process Closet Rebel YouTube shorts:
    1. Call Vidu API to generate 9:16 video
    2. Upload to YouTube
    3. Save clean mp4 to Drive for manual TikTok/Facebook posting
    4. Update sheet with status
    """
    title = data.get('title', 'Untitled')
    description = data.get('description', '')

    logging.info(f"Handling Closet Rebel YouTube: {title}")

    # Call Vidu API with 9:16 aspect ratio for shorts
    vidu_result = call_vidu_api(title, description, REBEL_VIDU_KEY, aspect_ratio="9:16")

    return {
        'title': title,
        'channel': 'rebel',
        'vidu_status': vidu_result.get('status'),
        'vidu_video_id': vidu_result.get('video_id'),
        'message': 'Rebel short video generation initiated'
    }


def handle_etsy(data, payload):
    """
    Process Etsy product posting:
    1. Call Etsy API to create draft listing
    2. Update sheet with listing URL
    3. Update sheet with status
    """
    title = data.get('title', 'Untitled Product')
    description = data.get('description', '')
    tags = data.get('tags', '')

    logging.info(f"Handling Etsy: {title}")

    try:
        # Etsy API endpoint for creating draft listing
        url = "https://openapi.etsy.com/v3/application/shops/self/listings"
        headers = {
            "x-api-key": ETSY_API_KEY,
            "Content-Type": "application/json"
        }

        listing_payload = {
            "title": title,
            "description": description,
            "quantity": 100,
            "price": 0.01,  # Placeholder, will update in draft
            "tags": tags.split(',') if tags else [],
            "state": "draft"
        }

        response = requests.post(url, json=listing_payload, headers=headers, timeout=30)

        if response.status_code in [200, 201]:
            result = response.json()
            listing_id = result.get('data', {}).get('listing_id')
            logging.info(f"Etsy draft listing created: {listing_id}")
            return {
                'title': title,
                'channel': 'etsy',
                'status': 'draft_created',
                'listing_id': listing_id,
                'message': 'Product draft created in Etsy'
            }
        else:
            logging.error(f"Etsy API error: {response.text}")
            return {
                'title': title,
                'channel': 'etsy',
                'status': 'error',
                'message': f'Etsy API error: {response.status_code}'
            }
    except Exception as e:
        logging.error(f"Etsy API call failed: {str(e)}")
        return {
            'title': title,
            'channel': 'etsy',
            'status': 'error',
            'message': str(e)
        }
